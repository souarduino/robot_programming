# pothole_detection > 2024-01-03 10:47pm
https://universe.roboflow.com/soumo-emmanuel-arnaud/pothole_detection-ajql6

Provided by a Roboflow user
License: CC BY 4.0

